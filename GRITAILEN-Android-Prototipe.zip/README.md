# GRITAILEN – Android Prototype

Prototipe awal game petualangan survival top-down menggunakan Godot 4.3 atau lebih baru.

## Fitur prototipe
- Gerakan karakter dengan WASD / tombol panah.
- Tombol sentuh pada layar untuk Android.
- Monster mengejar pemain dan mengurangi HP saat dekat.
- Satu kartu dapat dikumpulkan pada area awal.
- Tampilan HP, jumlah kartu, pesan misi, dan tombol mulai ulang.
- Grafis 2D sederhana yang digambar langsung melalui GDScript.

## Cara membuka
1. Instal Godot Engine versi 4.3 atau lebih baru di komputer.
2. Ekstrak ZIP ini.
3. Di Godot, pilih **Import** lalu pilih `project.godot`.
4. Tekan **Run Project**.

## Build APK Android
Proyek ini belum berupa APK dan belum diuji pada perangkat Android.
Untuk ekspor Android, siapkan Android export templates yang cocok dengan versi Godot, Android SDK, Java/JDK, lalu atur Editor Settings > Export > Android. Buat preset Android melalui Project > Export dan ekspor APK.
Untuk build cloud, unggah isi folder proyek ini ke GitHub lalu siapkan workflow GitHub Actions dan konfigurasi Android SDK/export template.

## Catatan
Ini adalah prototipe dasar untuk memulai pengembangan. Sistem 100 kartu, inventaris lengkap, boss, kamera 3D, penyimpanan, audio, dan misi lanjutan belum diimplementasikan.
