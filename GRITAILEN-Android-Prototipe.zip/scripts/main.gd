extends Node2D

const WORLD_SIZE := Vector2(1800, 1100)
const PLAYER_SPEED := 260.0
const ENEMY_SPEED := 105.0

var player_pos := Vector2(420, 420)
var enemy_pos := Vector2(760, 430)
var card_pos := Vector2(590, 300)
var hp := 100
var cards := 0
var mission_done := false
var hit_cooldown := 0.0
var held := {"up": false, "down": false, "left": false, "right": false}
var status_text := "Jelajahi pulau dan kumpulkan kartu!"
var camera: Camera2D

var hud: Label
var status_label: Label
var touch_layer: CanvasLayer

func _ready() -> void:
    camera = Camera2D.new()
    camera.position = player_pos
    add_child(camera)
    camera.enabled = true
    _make_ui()
    queue_redraw()

func _process(delta: float) -> void:
    var direction := Vector2.ZERO
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP) or held.up: direction.y -= 1
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN) or held.down: direction.y += 1
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT) or held.left: direction.x -= 1
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT) or held.right: direction.x += 1
    if direction.length() > 0:
        player_pos += direction.normalized() * PLAYER_SPEED * delta
    player_pos.x = clampf(player_pos.x, 35, WORLD_SIZE.x - 35)
    player_pos.y = clampf(player_pos.y, 70, WORLD_SIZE.y - 35)

    enemy_pos += (player_pos - enemy_pos).normalized() * ENEMY_SPEED * delta
    camera.position = player_pos
    hit_cooldown = maxf(0.0, hit_cooldown - delta)
    if player_pos.distance_to(enemy_pos) < 43 and hit_cooldown == 0.0:
        hp = maxi(0, hp - 10)
        hit_cooldown = 1.0
        status_text = "Monster menyerang! Hindari monster."
    if player_pos.distance_to(card_pos) < 42 and cards == 0:
        cards = 1
        status_text = "Kartu berhasil didapatkan! 1/3"
        card_pos = Vector2(-1000, -1000)
    if hp <= 0:
        status_text = "Kamu kalah. Tekan Mulai Ulang."
    _update_hud()
    queue_redraw()

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("#1d4939"))
    # grassy tiles
    for x in range(0, int(WORLD_SIZE.x), 96):
        for y in range(0, int(WORLD_SIZE.y), 96):
            if ((x / 96) + (y / 96)) % 2 == 0:
                draw_rect(Rect2(x, y, 94, 94), Color("#245642"))
    # paths and water border
    draw_rect(Rect2(0, 0, WORLD_SIZE.x, 30), Color("#277b91"))
    draw_rect(Rect2(0, WORLD_SIZE.y-28, WORLD_SIZE.x, 28), Color("#277b91"))
    for p in [Vector2(220,220), Vector2(1080,250), Vector2(1330,760), Vector2(420,820)]:
        draw_circle(p, 32, Color("#32694b"))
        draw_circle(p + Vector2(-9,-9), 11, Color("#4b8c5e"))
    # card
    if cards == 0:
        draw_colored_polygon(PackedVector2Array([card_pos+Vector2(0,-20), card_pos+Vector2(17,-10), card_pos+Vector2(17,10), card_pos+Vector2(0,20), card_pos+Vector2(-17,10), card_pos+Vector2(-17,-10)]), Color("#f2cf54"))
        draw_circle(card_pos, 5, Color("#fff3b0"))
    # enemy and player
    draw_circle(enemy_pos + Vector2(0, 9), 23, Color("#14231f"))
    draw_circle(enemy_pos, 22, Color("#a84343"))
    draw_circle(enemy_pos + Vector2(-7,-5), 5, Color.WHITE)
    draw_circle(enemy_pos + Vector2(7,-5), 5, Color.WHITE)
    draw_circle(player_pos + Vector2(0, 10), 19, Color("#14231f"))
    draw_circle(player_pos, 18, Color("#4b91e2"))
    draw_circle(player_pos + Vector2(-5,-5), 4, Color.WHITE)
    draw_circle(player_pos + Vector2(5,-5), 4, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(30, 65), "GRITAILEN • PULAU AWAL", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color.WHITE)

func _make_ui() -> void:
    touch_layer = CanvasLayer.new()
    add_child(touch_layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(12, 12)
    panel.custom_minimum_size = Vector2(270, 90)
    touch_layer.add_child(panel)
    var box := VBoxContainer.new()
    panel.add_child(box)
    hud = Label.new()
    hud.add_theme_font_size_override("font_size", 18)
    box.add_child(hud)
    status_label = Label.new()
    status_label.text = status_text
    status_label.add_theme_font_size_override("font_size", 14)
    box.add_child(status_label)

    _add_touch_button("▲", Vector2(90, -145), "up")
    _add_touch_button("▼", Vector2(90, -55), "down")
    _add_touch_button("◀", Vector2(18, -100), "left")
    _add_touch_button("▶", Vector2(162, -100), "right")
    var reset := Button.new()
    reset.text = "Mulai Ulang"
    reset.position = Vector2(770, 16)
    reset.size = Vector2(170, 48)
    reset.pressed.connect(_restart)
    touch_layer.add_child(reset)
    _update_hud()

func _add_touch_button(caption: String, offset: Vector2, key: String) -> void:
    var b := Button.new()
    b.text = caption
    b.position = Vector2(22, 540) + offset
    b.size = Vector2(64, 58)
    b.add_theme_font_size_override("font_size", 24)
    b.button_down.connect(func(): held[key] = true)
    b.button_up.connect(func(): held[key] = false)
    touch_layer.add_child(b)

func _update_hud() -> void:
    if is_instance_valid(hud):
        hud.text = "HP: %d    Kartu: %d/1" % [hp, cards]
    if is_instance_valid(status_label):
        status_label.text = status_text

func _restart() -> void:
    player_pos = Vector2(420, 420)
    enemy_pos = Vector2(760, 430)
    card_pos = Vector2(590, 300)
    hp = 100
    cards = 0
    hit_cooldown = 0
    status_text = "Jelajahi pulau dan kumpulkan kartu!"
